/*     README
 *      _____
 *  |  /-----\  |
 *  |\|-------|/|
 *   \|-------|/
 *    /\-----/\
 *   | /\___/\ |
 *    |  /W\  |
 *  /===^   ^===\
 * /|   ch ca   |\
 * V/  HdiSSdH  \V
 * (             )
 * 
 * (Chelifer cancroides)
 * (Homo doctus in se semper divitias habet.)
 * chca - simple tool for working with very primitive knowledge bases.
 *
 * compile and use
 *
 * if you use gcc, run:
 *
 * $ sudo gcc ./chca.c -o /bin/chca
 * $ chca h
 *
 * other information in README.chca
 *
 * Author:
 *          Jerzy Pavka
 *          mail jerzypavka@gmail.com
 *          site https://irrumator228.github.io/
 *
 * Version:
 *          0.0.1-egg of 28/02/2023
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <dirent.h>

char* VERSION = "chca-0.0.1-egg (c) 2023 Jerzy Pavka";

struct stack {
	char stck[100][100];
	unsigned int size;
	char str[100];
	unsigned int len[100];
	char type[100][5];
};

struct cur {
	unsigned int i;
	unsigned int j;
};

struct fstck {
	char f[100][100];
	char s[100][1000];
	unsigned int i[1000];
	unsigned int j[1000];
	unsigned int size;
};

struct stack stck1;

void printc(unsigned int i) {
	if ( i > 1) {
		for (unsigned int j = 0; j < i - 1; j++) printf(" ");
		printf("^\n");
	}
	else printf("^\n");
}

void merror (unsigned int n, char *s, unsigned int  i, unsigned int j) {
	char *err_s;
	switch (n) {
	case 1:
		err_s = "path not specified";
		break;
	case 2:
		err_s = "command not found";
		break;
	case 3:
		err_s = "open file";
		break;
	case 4:
		err_s = "close file";
		break;
	case 5:
		err_s = "unknown operator";
		break;
	case 6:
		err_s = "extra closing parenthesis";
		break;
	case 7:
		err_s = "unknown character";
		break;
	case 8:
		err_s = "extra opening parenthesis";
		break;
	case 9:
		err_s = "it's no such file or directory";
		break;
	case 10:
		err_s = "error in chca code";
		break;
	default:
		err_s = "unknown error";
		break;			
	}
	if ((i == 0) && (j == 0)) {
		printf("%s\n", s);
		printf("\n%u error. %s.\n", n, err_s);
	}
	else if (i == 0) {
		printf("%s\n", s);
		printc(j);
		printf("%u error. %s:%u\n", n, err_s, j);
	}
	else {
		printf("%s\n", s);
		printc(j);
		printf("%u error. %s. %s:%u:%u\n", n, err_s, s, i, j);
	}
	exit(EXIT_FAILURE);
}

void printer(unsigned int code, char *s, char *f, unsigned int i, unsigned int j) {
	switch (code) {
	case 1: //вывод вхождения из файла
		if (strlen(s) > 60) {
			if (j > 60) {
				char s1[60];
				for (int l = 0; l < 60; l++) {
					s1[l] = s[l + j - 21];
				}
				printf("  %s\n  ", s1);
				printc(j % 60);
			}
			else {
				char s1[60];
				for (int l = 0; l < 60; l++) {
					s1[l] = s[l];
				}
				printf("  %s\n  ", s1);
				printc(j % 60);
			}
		}
		else {
			printf("  %s  ", s);
			printc(j);
		}
		printf("%s:%u:%u\n", f, i, j);
		break;
	case 2: //вывод отсутствия вхождения
		printf("no entries found\n");
		printf("%s\n", f);
		break;
	default: //вывод дефолта.
		printf("chca");
		break;
	}
}

struct fstck find(char *s, char *f) {
	if ( f == NULL) merror(1, " ", 0, 0);
	char f_s[1000];
	FILE *file;
	file = fopen(f,"rt"); //только для чтения
	if (file == NULL) merror(3, f, 0, 0);
	bool done = false;

	struct fstck fstck1;
	unsigned int k = 0;

	for (unsigned int i = 0; fgets(f_s, 1000, file) != NULL; i++) {

		if (f_s[0] != ' ' && f_s[0] != ' ') {
			for (unsigned int j = 0; j < strlen(f_s); j++) {
				if (f_s[j] == s[0]) {
				for (unsigned int k = 0; k < strlen(s) && !done ; k++) {
					if (f_s[j + k] == s[k]) done = false;
					else done = true;
				}
				if (done == false) { strcpy(fstck1.f[k],f); strcpy(fstck1.s[k], f_s); fstck1.i[k] = i + 1, fstck1.j[k] = j + 1; fstck1.size = k+1; k++;}
				else done = false;
				}
			}
		}
	}
	fclose(file);
	if (k!=0) return fstck1;
	else { strcpy(fstck1.f[0], f); strcpy(fstck1.s[0], " "); fstck1.i[0] = 0, fstck1.j[0] = 0; fstck1.size = 1; return fstck1;}
}

int listdir(char *s) {
	DIR *d;
	struct dirent *dir;
	d = opendir(s);
	
	if (!d) merror(1, s, 0, 0);
	
	//if (dir->d_type == DT_REG) printf("%s\n", dir->d_name);
	unsigned int f_i = 0;

	if (d) {
		while ((dir = readdir(d)) != NULL) { 	
			if ((strcmp(dir->d_name,".") > 0) && (strcmp(dir->d_name,"..") > 0)) {
				
				//stack1.

				printf("%s\n", dir->d_name);
			}
		}
		closedir(d);
	}
	return(0);
}

void lexer(char *s) {
	unsigned int l = 0;
	struct cur cr = { 0 , 0 };

	char *s1 = "()&^!|\\?#,%%+=";
	char *s2 = "._/~-abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРCТУФХЦЧШЩЪЫЬЭЮЯ";
	bool done = false;
	for( unsigned int i = 0; i < strlen(s); i++ ) {
		switch (s[i]) {
		case '\n':
			l--;
			break;
		case '(':
			l++;
			break;
		case ')':
			l--;
			break;
		case ' ':
			stck1.stck[cr.i][0] = s[i];
			cr.j = 0;
			done = true;
			break;
		}
		for (unsigned int j = 0; (j < strlen(s1) && !done); j++) { 
			if (s[i] == s1[j]) {
				done = true;
				if (cr.j != 0) cr.i++;
				stck1.stck[cr.i][0] = s[i];
				cr.i++;
				cr.j = 0;
			}
		}
		for (unsigned int j = 0; (j < strlen(s2) && !done); j++) {
			if (s[i] == s2[j]) {
				done = true;
				stck1.stck[cr.i][cr.j] = s[i];
				cr.j++;
			}
		}



		if (!done) merror(7, s, 0, i);

		done = false;
	}
	stck1.size = cr.i + 1;
	//=========================================
	stck1.len[0] = 0;
	for (unsigned int i = 1; i < stck1.size; i++) {
		//printf("%s\n", stck1.stck[i]);
		stck1.len[i] = stck1.len[i-1] + strlen(stck1.stck[i]);
	}
	//=========================================
	if (l != 0) { merror(8, s, 0, stck1.len[stck1.size-1]); }
}

struct stack rlexer() {

}

void parser() {
	for (unsigned int i = 0; i < stck1.size; i++) {
		printf("%s\n", stck1.stck[i]);
		switch (stck1.stck[i][0]) {
		case '(':
		case ')':

			break;
		case '?':
		case '%':
			//stck1.type[i][0] = 'l';
			break;
		case '&':
		case '|':
		case '^':
		case '!':
			stck1.type[i][0] = 'o';
			break;
		case '1':
		case '0':
			stck1.type[i][0] = 'l';
			break;
		case '~':
		case '/':
			if (opendir(stck1.stck[i]) != NULL) { stck1.type[i][0] = 'd'; }
			else if (fopen(stck1.stck[i],"rt") != NULL) { stck1.type[i][0] = 'f'; }
			else merror(9, stck1.stck[i], 0, 0);
			break;
		default:
			stck1.type[i][0] = 'q';
			break;
		}
	}
}

void runer() {
	struct fstck fstck1; 

	for (unsigned int i = 0; i < stck1.size; i++) {
		
		if (stck1.type[i][0] == 'q') {

			for (unsigned int j = 0; j < stck1.size; j++) {

				if (stck1.type[j][0] == 'f') {
					struct fstck fstck1 = find(stck1.stck[i], stck1.stck[j]);

					if (fstck1.size > 1) {
						for (unsigned int j = 0; j < fstck1.size; j++) {
							printer(1, fstck1.s[j], fstck1.f[j], fstck1.i[j], fstck1.j[j]);
						}
					}
					else printer(2, " ", fstck1.f[0], 0, 0);
				}
			}
		}
	}
}

bool logic(int argc, bool argv[], char c) {
	switch (c) {
	case '&':
		//for (unsigned int i = 2)
		return (argv[1] && argv[2]);
		break;
	case '|':
		return (argv[1] || argv[2]);
		break;	
	case '!':
		return (!argv[1]);
		break;
	case '^':
		return (argv[1] ^ argv[2]);
		break;
	default:
		merror(5," ",0,0);
		break;
	}
}

int main(int argc, char *argv[]) {
	setlocale(LC_CTYPE, "Russian.UTF-8"); /*change your language*/
	if (argc > 1) {
		switch (argv[1][0]) {
		case '(':
			lexer(argv[1]);
			parser();
			runer();
			exit(EXIT_SUCCESS);
			break;
		case 'h':
			printf("commands:\nh - help;\nv - version;\nother commands and tutorial in file README.chca\n");
			exit(EXIT_SUCCESS);
			break;
		case 'v':
			printf("%s\n", VERSION);
			exit(EXIT_SUCCESS);
			break;
		default :
			printf("try h for help.\n");
			exit(EXIT_SUCCESS);
			break;
		}
		return 0;
	}
	else {
		printf("try h for help.\n");
		for(;;) {
			printf(">");
			char s[1000];
			scanf("%s", s);
			printf("command = '%s'\n",s);
			switch(s[0]) {
			case '(':
				lexer(s);
				parser();
				runer();
				break;
			case 'h':
				printf("commands:\nh - help;\nv - version;\nq - quit;\nother commands and tutorial in file README.chca;\n");
				break;
			case 'v':
				printf("%s\n", VERSION);
				break;
			case 'q':
				exit(EXIT_SUCCESS);
				break;
			default:
				printf("try h for help.\n");
				break;
			}
		}

	} 
}