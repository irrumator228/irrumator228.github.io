/*     README
 *      _____  
 *  |  /-----\  |
 *  |\|-------|/|
 *   \|-------|/
 *    /\-----/\
 *   | /\___/\ |
 *    |  /W\  |
 *  /===^   ^===\
 * /|   ch ca   |\
 * V/  HdiSSdH  \V
 * (             )
 * 
 * (Chelifer cancroides)
 * (Homo doctus in se semper divitias habet.)
 * chca - simple tool for working with very primitive knowledge bases.
 * 
 * compile and use
 * $ sudo gcc ./chca.c -o /bin/chca
 * $ chca h
 * 
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <dirent.h> 

char stack[100][100];
uint stack_size;
char str[100];
uint stack_len[100];

void merror (uint n, char *s, uint  i, uint j) {
	char *err_s;
	switch (n) {
	case 1:
		err_s = "path not specified";
		break;
	case 2:
		err_s = "command not found";
		break;
	case 3:
		err_s = "open file";
		break;
	case 4:
		err_s = "close file";
		break;
	case 5:
		err_s = "unknow operator";
		break;
	case 6:
		err_s = "extra closing parenthesis";
		break;
	case 7:
		err_s = "unknown character";
		break;
	case 8:
		err_s = "extra opening parenthesis";
		break;
	default:
		err_s = "unknow error";			
	}
	if (i == 0) {
		printf("%s\n", s);
		for (uint k = 0; k < j ; k++) printf(" ");
		printf("^\n%u error. %s.\n", n, err_s);
	}
	else {
		printf("%s\n", s);
		for (uint k = 0; k < j ; k++) printf(" ");
		printf("^\n%u error. %s. %s:%u:%u\n", n, err_s, s, i, j);
	}
	exit(EXIT_FAILURE);
}

/*
((#tag.програм%ирование)(#tag.база?знаний)&)
((баз%)(знан%)& (~/my_projects/мусор/) (~/my_projects/chca/)-)
(#tag.программ%)
*/

void analcom() {
	uint l = 0;
	for(uint i = 0; i < stack_size; i++) {
		switch (stack[i][0]) {
		case '(':
			//printf("%u++ i = %u\n", l, i);
			l++;
			break;
		case ')':
			//printf("%u-- i = %u\n", l, i);
			if (l <= 0) merror(6, str, 0, stack_len[i]);
			l--;
			break;
		case '&':
		case '^':
		case '!':
		case '|':
			break;
		case '#':
			break;
		case '.':
			break;
		case ',':
			break;
		case '?':
			break;
		case '%':
			break;
		case '\\':
			break;
		case '/':
			break;
		default:
		}
		//printf("%s\n", stack[i]);
	}
	if (l != 0) { merror(8, str, 0, stack_len[stack_size-1]); }
}

void parser(char *s) {
	uint stack_i = 0;
	uint stack_j = 0;
	char *s1 = "()&^!|\\/?#.,%%~-+= ";
	char *s2 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"; /*абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ*/
	bool done = false;
	for( uint i = 0; i < strlen(s); i++ ) {
		for (uint j = 0; (j < strlen(s1) && !done); j++) { 
			if (s[i] == s1[j]) { 
				done = true;
				if (stack_j != 0) stack_i++;
				stack[stack_i][0] = s[i];
				stack_i++;
				stack_j = 0;
			}
		}
		for (uint j = 0; (j < strlen(s2) && !done); j++) {
			if (s[i] == s2[j]) {
				done = true;
				stack[stack_i][stack_j] = s[i];
				stack_j++;
				}
			}
		if (!done) merror(7, s, 0, i);
		done = false;
	}
	stack_size = stack_i;
	//=========================================
	stack_len[0] = 0;
	for (uint i = 1; i < stack_size; i++) {
		stack_len[i] = stack_len[i-1] + strlen(stack[i]);
	}
}

int analfile() {

}

int newstring() {

}

bool logic(int argc, bool argv[], char c) {
	switch (c) {
	case '&':
		return (argv[1] && argv[2]);
		break;
	case '|':
		return (argv[1] || argv[2]);
		break;	
	case '!':
		return (!argv[1]);
		break;
	case '^':
		return (argv[1] ^ argv[2]);
		break;
	default:
		merror(5," ",0,0);
	}
}

int main(int argc, char *argv[]) {
setlocale(LC_CTYPE, "Russian.UTF-8"); /*change your language*/
if (argc < 2) { printf("try h for help.\n"); exit(EXIT_SUCCESS); }

switch (argv[1][0]){
case '(':
	strcat(str, argv[1]);
	//printf("%s\n", argv[1]);
	parser(argv[1]);
	analcom();
	analfile();
	exit(EXIT_SUCCESS);
	break;
case 'h':
	printf("commands:\nh - help;\nv - version;\nc /sourcefile /targetfile - create note\nd /targetfile - debug\nquery:\nlogic:\n! - not\n& - and\n= - равно\n| - or\n^ - xor\nother:\nt - # (t=name.chca)\n");
	exit(EXIT_SUCCESS);
	break;
case 'v':
	puts("chca-egg © 2023 Jerzy Pavka\n");
	exit(EXIT_SUCCESS);
	break;
default :
	printf("try h for help.\n");
	exit(EXIT_SUCCESS);
}
return 0;
}

/*
int listdir(char *s) {
	DIR *d;
	struct dirent *dir;
	d = opendir("");
	if (dir->d_type == DT_REG)	printf("%s\n", dir->d_name);
	if (d) {
		while ((dir = readdir(d)) != NULL)	printf("%s\n", dir->d_name);
		closedir(d);
		}
	return(0);
}

список вершин:
chca
искуственный_интеллект
символический_искусственный_интеллект
цеттелькастен
теория_графов

список рёбер

chca                                  ---> теория_графов
chca                                  ---> символический_искусственный_интеллект
chca                                  ---> цеттелькастен
символический_искусственный_интеллект ---> искуственный_интеллект


	//analising files 
	char *fp;
	char *fp_s;
	//if (argv[2] == NULL) fp = argv[2];
	if ( fp == NULL) merror(1, fp, 0, 0);
	FILE *file;
	file = fopen(fp,"a+");
	if (file == NULL) merror(3, fp, 0, 0);
	for (uint i = 1;i < argc; i++) {
	for (uint j = 1;j < argc; j++) {
		fscanf(file, "%s", fp_s);
	}
	}

	fclose(file);


#include <>
#define 
enum {}
typedef enum {}


char *query(char *s) {
	char *result;
    result = (char *)malloc(100 * sizeof(char));
	result = "";
 	strcpy(result,"p");
	return result;
}


[1][2        ][3   ][4]
[A][Jmilevski][0.45][Y]
[B][Rudoy    ][0   ][X]
[C][Vasilev  ][0.1 ][Y]
[D][Lohov    ][0.3 ][ ]
[E][Remek    ][-45 ][ ]

*/