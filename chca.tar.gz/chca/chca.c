/* README
 *      _____  
 *  |  /-----\  |
 *  |\|-------|/|
 *   \|-------|/
 *    /\-----/\
 *   | /\___/\ |
 *    |  /W\  |
 *  /===^   ^===\
 * /|   ch ca   |\
 * V/  HdiSSdH  \V
 * (             )
 * 
 * (Chelifer cancroides)
 * (Homo doctus in se semper divitias habet.)
 * chca - simple tool for working with very primitive knowledge bases.
 * 
 * compile and use
 * $ sudo gcc ./chca.c -o /bin/chca
 * $ chca h
 * 
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <dirent.h> 
#include <stdio.h> 

/*
int debugp(char *s) {
	DIR *d;
	struct dirent *dir;
	d = opendir(".");
	if (dir->d_type == DT_REG)
	{
    	printf("%s\n", dir->d_name);
  	}
	if (d) {
	while ((dir = readdir(d)) != NULL) {
    	printf("%s\n", dir->d_name);
	}
	closedir(d);
	}
	return(0);
}
*/

int debug(char *s) {
	if (s == NULL) { printf("error. path not specified\n"); return 1; } //подстраховка
	FILE *fp;
	//if (fopen(s,"a+") != 0) { printf("error open file\n"); return 1; }
	fp = fopen(s,"a+");
	if (fp == NULL) { printf("error. open file.\n"); return 1; }

	for (ulong i = 1; ((!feof(fp)) && (i<1000 /*пофиксите*/)); i++) {
		char fp_s[100]; //ограничение на длину строки
		//if (fscanf(fp, "%s", fp_s) != 0) { printf("error. read file string '%lu'\n", i); return 1; }
		fscanf(fp, "%s", fp_s);
		for (ulong j = 0; (j < strlen(fp_s)); j++) {
			ushort k = 1;
			switch (fp_s[j]) {
			case '#':
				k = 1;
				while ((j+k) < strlen(fp_s)) {
					switch (fp_s[j+k]) {
					case '.':
						break;
					case ',':
						break;
					default:
						break;
					}
					k++;
				}
				j = j + k;
				break;
			case '{':
				break;
			case '/':
				k = 1;
				while ((j+k) < strlen(fp_s)) {
					switch (fp_s[j+k]) {
					case '*':
						break;
					case '0':
					case '1':
					case '2':
					case '3':
					case '4':
					case '5':
					case '6':
					case '7':
					case '8':
					case '9':
						break;
					case '.':
						break;
					case '(':

						/*
						ushort l = 1;
						while ((j+k+l) < strlen(fp_s)) {
							switch (fp_s[j+k+l])
							{
							case ')':
								if (fp_s[j+k+l+1]<strlen(fp_s)) { 
									printf("error. %s:%lu:%lu '%c'\n", s, i, (j+1+k+l), fp_s[j+k+l]); 
									return 1;
								}
								break;
							default:
								break;
							}
						}
						*/

						break;
					default:
						printf("error. %s:%lu:%lu '%c'\n", s, i, (j+1+k), fp_s[j+k]); 
						return 1;
						break;
					}
					k++;
				}
				j = j + k;
				break;
			default:
				printf("error. %s:%lu:%lu '%c'\n", s, i, (j+1), fp_s[j]); 
				return 1;
				break;
			}
		}
	}

	fclose(fp);
	return 0;
}

int main(int argc, char *argv[]) {
setlocale(LC_CTYPE, "Russian"); /*change your language*/

if (argc < 2) { printf("try h for help.\n"); exit(EXIT_SUCCESS); }

switch(argv[1][0]) {
case ':': /*command*/
	for (ushort i = 1;(i < strlen(argv[1]) && (i < 65533 /*а вдруг блять*/)); i++) {
		switch(argv[1][i]) {
		case 'v':/*viev all vetka*/

			break;
		default:
			printf("error. command \"%c\" not found\n", argv[1][i]);
			exit(EXIT_FAILURE);
		}
		char *df;/*directory or file path*/
		if (argv[2] != NULL) { df = argv[2]; printf("path \"%s\"\n", df); }
		else df = "~/";
	}

	exit(EXIT_SUCCESS);
	break;
case 'd':
	if (argv[2] != NULL) if (debug(argv[2]) != 0) exit(EXIT_FAILURE);
	printf("debugging was successful");
	exit(EXIT_SUCCESS);
	break;
case 'h':
	printf("commands:\nh - help;\nv - version;\nc /sourcefile /targetfile - create note\n:[g - graph | ] /dirname_or_sourcefile - query\nd /targetfile - debug\n");
	exit(EXIT_SUCCESS);
	break;
case 'v':
	puts("chca-egg © 2023 Jerzy Pavka\n");
	exit(EXIT_SUCCESS);
	break;
default :
	printf("try h for help.\n");
	exit(EXIT_SUCCESS);
}
return 0;
}