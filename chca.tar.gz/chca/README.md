 # chca
 
 <pre>     _____  
 |  /-----\  |
 |\|-------|/|
  \|-------|/
   /\-----/\
  | /\___/\ |
   |  /W\  |
 /===^   ^===\
/|   ch ca   |\
V/  HdiSSdH  \V
(             )</pre>

*(chelifer cancroides)*
*(homo doctus in se semper divitias habet)*

**chca** - simple tool for working with very primitive knowledge bases.

compile and use

     sudo gcc ./chca.c -o /bin/chca
     chca h
